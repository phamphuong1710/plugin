<?php
/*
Plugin Name: Barbie Widget
Plugin URI: https://google.com
Description: Barbie Widget.
Author: Bootify
Version: 1.0
Author URI: http://haintheme.com
*/

include plugin_dir_path( __FILE__ ) . 'widgets/class-barbie-widget-recent-posts.php';
include plugin_dir_path( __FILE__ ) . 'widgets/class-barbie-widget-product-fillter.php';

/**
 * Register Widgets.
 */
function barbie_register_widgets() {
	register_widget( 'Barbie_Widget_Recent_Posts' );

	if ( class_exists( 'WooCommerce' ) && class_exists( 'TA_WC_Variation_Swatches' ) ) {
		register_widget( 'Barbie_Widget_Products_Filter' );
	}
}
add_action( 'widgets_init', 'barbie_register_widgets' );
